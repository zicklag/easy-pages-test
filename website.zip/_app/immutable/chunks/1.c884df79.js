import{default as t}from"../entry/error.svelte.4873b0b5.js";export{t as component};
